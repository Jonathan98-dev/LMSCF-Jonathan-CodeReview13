<?php
namespace App\Controller;

// We need to import Response, Route, Request and Controller if we want to use them
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

// Now we need some classes in our Controller because we need that in our form (for the inputs that we will create)
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Validator\Constraints\Regex;
use App\Entity\Events;

class eventsController extends Controller
{
	 /**
		* @Route("/", name="home_page")
		*/
	public function showAction()
	{	
	//brings all the data from database and saves it in events variable
	$events = $this->getDoctrine()->getRepository('App:Events')->findAll();
	// sending variable to index.html.twig
	return $this->render('events/index.html.twig',array('events'=>$events));	

	}

	/**
	* @Route("/create", name="create_page")
	*/
	public function createAction(Request $request)
	{
		$event = new Events;

		$form = $this->createFormBuilder($event)
		->add('eventName', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventDate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

		->add('eventDescription', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventImage', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventCapacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventEmail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventTel', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventAddress', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventUrl', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventType', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))

		->getForm();
		$form->handleRequest($request);
       

	if($form->isSubmitted() && $form->isValid())
	{

		$eventName = $form['eventName']->getData();
		$eventDate = $form['eventDate']->getData();
		$eventDescription = $form['eventDescription']->getData();
		$eventImage = $form['eventImage']->getData();
		$eventCapacity = $form['eventCapacity']->getData();
		$eventEmail = $form['eventEmail']->getData();
		$eventTel = $form['eventTel']->getData();
		$eventAddress = $form['eventAddress']->getData();
		$eventUrl = $form['eventUrl']->getData();
		$eventType = $form['eventType']->getData();


		$event->setEventName($eventName);
		$event->setEventDate($eventDate);
		$event->setEventDescription($eventDescription);
		$event->setEventImage($eventImage);
		$event->setEventCapacity($eventCapacity);
		$event->setEventEmail($eventEmail);
		$event->setEventTel($eventTel);
		$event->setEventAddress($eventAddress);
		$event->setEventUrl($eventUrl);
		$event->setEventType($eventType);

		$em = $this->getDoctrine()->getManager();
		$em->persist($event);
		$em->flush();
		$this->addFlash('notice','New Event Created');

		return $this->redirectToRoute('home_page');
    }
	return $this->render('events/create.html.twig', array('form' => $form->createView()));
}
	

	/**
	* @Route("/edit/{id}", name="edit_page")
	*/
	public  function editAction($id, Request $request)
	{
		$event = $this->getDoctrine()->getRepository('App:Events')->find($id);

		$event->setEventName($event->getEventName());
		$event->setEventDate($event->getEventDate());
		$event->setEventDescription($event->getEventDescription());
		$event->setEventImage($event->getEventImage());
		$event->setEventCapacity($event->getEventCapacity());
		$event->setEventEmail($event->getEventEmail());
		$event->setEventTel($event->getEventTel());
		$event->setEventAddress($event->getEventAddress());
		$event->setEventUrl($event->getEventUrl());
		$event->setEventType($event->getEventType());

		$form = $this->createFormBuilder($event)
		->add('eventName', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventDate', DateTimeType::class, array('attr' => array('style'=>'margin-bottom:15px')))

		->add('eventDescription', TextareaType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventImage', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventCapacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventEmail', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventTel', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventAddress', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventUrl', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('eventType', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

		->add('save', SubmitType::class, array('label'=> 'Create Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))

		->getForm();

		$form->handleRequest($request);

	if($form->isSubmitted() && $form->isValid())
		{

			$eventName = $form['eventName']->getData();
			$eventDate = $form['eventDate']->getData();
			$eventDescription = $form['eventDescription']->getData();
			$eventImage = $form['eventImage']->getData();
			$eventCapacity = $form['eventCapacity']->getData();
			$eventEmail = $form['eventEmail']->getData();
			$eventTel = $form['eventTel']->getData();
			$eventAddress = $form['eventAddress']->getData();
			$eventUrl = $form['eventUrl']->getData();
			$eventType = $form['eventType']->getData();

			$em = $this->getDoctrine()->getManager();
			$event = $em -> getRepository('App:Events')->find($id);

			$event->setEventName($eventName);
			$event->setEventDate($eventDate);
			$event->setEventDescription($eventDescription);
			$event->setEventImage($eventImage);
			$event->setEventCapacity($eventCapacity);
			$event->setEventEmail($eventEmail);
			$event->setEventTel($eventTel);
			$event->setEventAddress($eventAddress);
			$event->setEventUrl($eventUrl);
			$event->setEventType($eventType);

			$em->flush();
			$this->addFlash('notice','Event Updated');

			return $this->redirectToRoute('home_page');
	    }
		return $this->render('events/edit.html.twig', array('form' => $form->createView()));
	}


	/**
	* @Route("/details/{id}", name="details_page")
	*/
	public  function detailsAction($id)
	{
		$event = $this->getDoctrine()->getRepository('App:Events')->find($id);
		return $this->render('events/details.html.twig', array('event'=>$event));
	}


	/**
	* @Route("/delete/{id}", name="Event_delete")
	*/
	public function deleteAction($id)
	{
		$em = $this->getDoctrine()->getManager();
		$event = $em->getRepository('App:Events')->find($id);
		$em->remove($event);
		$em->flush();
		
		return $this->redirectToRoute('home_page');
	}


}

?>