<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\EventsRepository")
 */
class Events
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventName;

    /**
     * @ORM\Column(type="datetime")
     */
    private $eventDate;

    /**
     * @ORM\Column(type="string", length=1000)
     */
    private $eventDescription;

    /**
     * @ORM\Column(type="string", length=500)
     */
    private $eventImage;

    /**
     * @ORM\Column(type="integer")
     */
    private $eventCapacity;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventEmail;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventTel;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $EventAddress;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventUrl;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $eventType;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEventName(): ?string
    {
        return $this->eventName;
    }

    public function setEventName(string $eventName): self
    {
        $this->eventName = $eventName;

        return $this;
    }

    public function getEventDate(): ?\DateTimeInterface
    {
        return $this->eventDate;
    }

    public function setEventDate(\DateTimeInterface $eventDate): self
    {
        $this->eventDate = $eventDate;

        return $this;
    }

    public function getEventDescription(): ?string
    {
        return $this->eventDescription;
    }

    public function setEventDescription(string $eventDescription): self
    {
        $this->eventDescription = $eventDescription;

        return $this;
    }

    public function getEventImage(): ?string
    {
        return $this->eventImage;
    }

    public function setEventImage(string $eventImage): self
    {
        $this->eventImage = $eventImage;

        return $this;
    }

    public function getEventCapacity(): ?int
    {
        return $this->eventCapacity;
    }

    public function setEventCapacity(string $eventCapacity): self
    {
        $this->eventCapacity = $eventCapacity;

        return $this;
    }

    public function getEventEmail(): ?string
    {
        return $this->eventEmail;
    }

    public function setEventEmail(string $eventEmail): self
    {
        $this->eventEmail = $eventEmail;

        return $this;
    }

    public function getEventTel(): ?string
    {
        return $this->eventTel;
    }

    public function setEventTel(string $eventTel): self
    {
        $this->eventTel = $eventTel;

        return $this;
    }

    public function getEventAddress(): ?string
    {
        return $this->EventAddress;
    }

    public function setEventAddress(string $EventAddress): self
    {
        $this->EventAddress = $EventAddress;

        return $this;
    }

    public function getEventUrl(): ?string
    {
        return $this->eventUrl;
    }

    public function setEventUrl(string $eventUrl): self
    {
        $this->eventUrl = $eventUrl;

        return $this;
    }

    public function getEventType(): ?string
    {
        return $this->eventType;
    }

    public function setEventType(?string $eventType): self
    {
        $this->eventType = $eventType;

        return $this;
    }
}
